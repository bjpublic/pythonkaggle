
## Project
- 아래는 프로젝트 설명 예시입니다.

:point_right: **프로젝트 이름**  
- **주 사용 언어 및 작업툴**: R, Python, RStudio, PyCharm, Google Colab, Jupyter Notebook
- **인원**: 3명  
- **기간**: 2021.01.03 - 2021.01.31  
- **내용**
  - 지도학습 알고리즘을 활용한 주택가격 예측  
- **선정 주제**
  - **House Prices - Advanced Regression Techniques**  
    - Predict sales prices and practice feature engineering, RFs, and gradient boosting
- **기여**: 데이터 전처리, 시각화, 주요 알고리즘 정리, PPT 작성  
- **결과**: 최종 RMSE 0.00012 / 200(전체 참가 팀: 1005팀][→ 캐글 노트북](https://www.kaggle.com/c/house-prices-advanced-regression-techniques/leaderboard)
  - 여러분들이 보여주고자 캐클 노트븍 링크를 대체 하시면 됩니다. 

<br>

:point_right: **트위터 NLT 참여 대회**  
- 참여 목적: 자연어 처리 경험 및 분류 모형 개발
- **언어 및 작업툴**: python, jupyter notebook
- **인원**: 2명
- **기간**: 2021.02.01 - 2021.02.28
- **내용**
  - 가짜 뉴스 판별기 알고리즘 개발
- **기여**: 평가지표 정리 및 파워포인트 작성
- **결과**: 최종 F1 Score 0.789 / 409(전체 참가 팀: 2825팀)[→ 캐글 노트북](https://www.kaggle.com/c/nlp-getting-started/overview/evaluation)
  - 여러분들이 보여주고자 캐클 노트븍 링크를 대체 하시면 됩니다. 

<br>

## 참고자료

- 그 외 마크다운 사용법 정리 영상 [`Git #3]` 마크다운(Markdown) 사용법, 문법 정리 Readme.md 파일 작성](https://www.youtube.com/watch?v=dUbp9wAy178)
- 프로젝트 PPT 결과물 예시
  - 서울특별시 빅데이터 캠퍼스 공모전 게시판: https://bigdata.seoul.go.kr/noti/selectPageListTabNoti.do?r_id=P260
  - [2020 빅데이터캠퍼스 공모전 - 서울특별시장상] 서울시 공공 와이파이 우선 입지 선정 PDF 파일을 첨부하였습니다. 